/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_pedidos_restaurante;

/**
 *
 * @author Thiago
 */
public class Pedido {
    Cliente cliente;
    Prato prato1;
    Prato prato2;
    Prato prato3;
    private static int num_pedido = 0;
    
    public Pedido(Cliente cliente){
        
        this.cliente = cliente;
        num_pedido++;
    }
    
    public void adicionarPrato(Prato prato)
    {
        int contadorPratos = 0;
        if(prato1 == null){
            prato1 = prato;
            contadorPratos++;
        }
        else if(prato2 == null){
            prato2 = prato;
            contadorPratos++;
        }
        else if(prato3 == null){
            prato3 = prato;
            contadorPratos++;
        }
    }
    
    public void calcularTotal(){
        double total = 0;
        if (prato1 != null) total += prato1.getPreco();
    if (prato2 != null) total += prato2.getPreco();
    if (prato3 != null) total += prato3.getPreco();
        System.out.println("Total a pagar: " + total);
    }

    public static int getNum_pedido() {
        return num_pedido;
    }
    
    
    
    
    
    @Override
    public String toString(){
        String detalhes = "Cliente: " + cliente.toString() + "\n";
        
    if (prato1 != null) {
        detalhes += "Prato 1: " + prato1.toString() + "\n";
    }
    if (prato2 != null) {
        detalhes += "Prato 2: " + prato2.toString() + "\n";
    }
    if (prato3 != null) {
        detalhes += "Prato 3: " + prato3.toString() + "\n";
    }
        
        return detalhes;
    }
}

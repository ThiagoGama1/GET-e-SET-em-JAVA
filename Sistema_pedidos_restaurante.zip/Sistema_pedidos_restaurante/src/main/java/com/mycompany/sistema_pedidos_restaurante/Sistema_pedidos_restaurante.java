/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_pedidos_restaurante;

/**
 *
 * @author Thiago
 */
public class Sistema_pedidos_restaurante {

    public static void main(String[] args) {
        // Criando cliente
        Cliente Thiago = new Cliente("Thiago");
        Thiago.setTelefone("0000000");

        
        Prato a = new Prato("Strogonoff", 30.0, "Principal");
        Prato b = new Prato("Batata frita", 25.0, "Entrada");
        Prato c = new Prato("Petit Gateou", 35.0, "Sobremesa");

     
        Pedido pedido = new Pedido(Thiago);

       
        pedido.adicionarPrato(a);
        pedido.adicionarPrato(b);

       
        System.out.println("Detalhes do pedido:");
        System.out.println(pedido); 

       
        System.out.println("\nCalculando total do pedido:");
        pedido.calcularTotal();

      
        System.out.println("\nNúmero total de pedidos realizados: " + Pedido.getNum_pedido());
        
        
        System.out.println("\nAdicionando mais um prato ao pedido...");
        pedido.adicionarPrato(c); 
        System.out.println(pedido); 

        
        System.out.println("\nCalculando o total após adicionar o terceiro prato:");
        pedido.calcularTotal(); 
    }
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_pedidos_restaurante;

/**
 *
 * @author Thiago
 */
public class Prato {
    private String nome;
    private double preco;
    private String tipo;
    
    public Prato(String nome, double preco, String tipo){
        this.nome = nome;
        this.preco = preco;
        this.tipo = tipo;
    }

    public double getPreco() {
        return preco;
    }
    
    
    @Override
    public String toString(){
        return "Nome: " + this.nome + "\n" + "Preco " + this.preco
                + "\n" + "Tipo: " + this.tipo;
    } 
}

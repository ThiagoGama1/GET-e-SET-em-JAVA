/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conta.bancaria;

/**
 *
 * @author Thiago
 */
public class Conta {
    private String titular;
    private double saldo;
    
    //métodos//
    public String getTitular(){
        return titular;
    }
    
    public void setTitular(String titular){
        this.titular = titular;
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void depositar(double valor){
        saldo += valor;
    }
    public void sacar(double valor){
        if(valor <= saldo)
        {
            saldo -= valor;
        }
        
        else{
            System.out.println("Valor indisponível");
        }
    }
}

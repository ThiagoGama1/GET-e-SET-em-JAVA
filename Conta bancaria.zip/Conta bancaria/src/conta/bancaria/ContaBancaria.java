/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conta.bancaria;
import java.util.Scanner;
/**
 *
 * @author Thiago
 */
public class ContaBancaria {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        double valor;
        int resposta = 3;
        Scanner b;
        b = new Scanner(System.in);
        
        Conta a = new Conta();
        
        while(resposta != 0){
            
        
        System.out.println("Digite 1 para depositar, 2 para sacar ou 0 para sair:");
        resposta = b.nextInt();
        switch(resposta){
            case 1: System.out.println("Qual o valor do depósito?");
            valor = b.nextDouble();
            a.depositar(valor);
            System.out.println("Depósito concluído! Saldo atual: " + a.getSaldo());
            
            break;
            
            case 2: System.out.println("Qual é o valor do saque?");
            valor = b.nextDouble();
            a.sacar(valor);
            break;
            
            case 0: System.out.println("Saindo...");
            break;
            
            default:
                System.out.println("Opção inválida");
                break;
        }
        System.out.println("Saldo final: " + a.getSaldo());
        }
    }
    
}
